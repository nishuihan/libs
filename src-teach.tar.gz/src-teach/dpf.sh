export LD_LIBRARY_PATH=
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../jpeg-8/.libs:
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../freetype-2.3.11/objs/.libs
